-- phpMyAdmin SQL Dump
-- version 4.0.10.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 23, 2015 at 02:32 AM
-- Server version: 5.5.40
-- PHP Version: 5.5.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shadowsocks`
--

-- --------------------------------------------------------

--
-- Table structure for table `invite_code`
--

CREATE TABLE IF NOT EXISTS `invite_code` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `user` int(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3665 ;

--
-- Dumping data for table `invite_code`
--

INSERT INTO `invite_code` (`id`, `code`, `user`) VALUES
(3639, '193c77e35a4a3f', 1),
(3651, 'fresaE3YWI4NGZiNDM0MDIxMDZjNT', 0),
(3652, 'fresa2U0ODk3NjEzODE2NmRlMzI3N', 0),
(3653, 'fresakNDgzNjcxMmM1ZTc3NTUwODk', 0),
(3655, 'fresaNjczMzA3Y2E3NDU5YmNmNzVm', 0),
(3657, 'fresaNDA1MjFkOTkwNzFjOTNhZjM5', 0),
(3658, 'fresazZjAyNzMyN2Q4NDYxMDYzZjR', 0),
(3659, 'fresaTJlOWE2OGM1YWUxMmJkMTg0O', 0),
(3660, 'fresaYjMxZDAxNmZmY2JmMzMxNGRm', 0),
(3662, 'fresaY2MwZmYwMjI4NzdiZDNkZjk0', 0),
(3664, 'fresawYjY0MjA0YTMwODhhMjZiYzJ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ss_admin`
--

CREATE TABLE IF NOT EXISTS `ss_admin` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(128) CHARACTER SET utf8mb4 NOT NULL,
  `email` varchar(32) NOT NULL,
  `pass` varchar(32) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ss_admin`
--

INSERT INTO `ss_admin` (`uid`, `admin_name`, `email`, `pass`) VALUES
(1, 'admin', 'admin@gmail.com', 'b4328659d8289e07cca449f61b7155ec');

-- --------------------------------------------------------

--
-- Table structure for table `ss_node`
--

CREATE TABLE IF NOT EXISTS `ss_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `node_name` varchar(128) NOT NULL,
  `node_type` int(3) NOT NULL,
  `node_server` varchar(128) NOT NULL,
  `node_method` varchar(64) NOT NULL,
  `node_info` varchar(128) NOT NULL,
  `node_status` varchar(128) NOT NULL,
  `node_order` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ss_node`
--

INSERT INTO `ss_node` (`id`, `node_name`, `node_type`, `node_server`, `node_method`, `node_info`, `node_status`, `node_order`) VALUES
(1, '日本节点1', 0, 'jp1.ssnodes.ml', 'aes-256-cfb', '日本节点，可翻墙。', '可用', 0),
(2, '日本节点2', 0, 'jp2.ssnodes.ml', 'aes-256-cfb', '日本节点，可翻墙。', '可用', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ss_reset_pwd`
--

CREATE TABLE IF NOT EXISTS `ss_reset_pwd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `init_time` int(11) NOT NULL,
  `expire_time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `uni_char` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ss_reset_pwd`
--

INSERT INTO `ss_reset_pwd` (`id`, `init_time`, `expire_time`, `user_id`, `uni_char`) VALUES
(0, 1424448190, 1424534590, 1, '2MzU5ODFkYzM4MmVkZTM2ZTdjNGNhNDI'),
(1, 1428819662, 1428906062, 20, 'Mjc4YmQ5ZTRlZDBjMWI1YzE2NTM5MTE3'),
(2, 1429531340, 1429617740, 21, 'WE0Njg1OWU1NTNkNGQzYzU5ZGMwNDhlO');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(128) CHARACTER SET utf8mb4 NOT NULL,
  `email` varchar(32) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `passwd` varchar(16) NOT NULL,
  `t` int(11) NOT NULL DEFAULT '0',
  `u` bigint(20) NOT NULL,
  `d` bigint(20) NOT NULL,
  `plan` varchar(2) CHARACTER SET utf8mb4 NOT NULL,
  `transfer_enable` bigint(20) NOT NULL,
  `port` int(11) NOT NULL,
  `switch` tinyint(4) NOT NULL DEFAULT '1',
  `enable` tinyint(4) NOT NULL DEFAULT '1',
  `type` tinyint(4) NOT NULL DEFAULT '1',
  `last_get_gift_time` int(11) NOT NULL DEFAULT '0',
  `last_check_in_time` int(11) NOT NULL DEFAULT '0',
  `last_rest_pass_time` int(11) NOT NULL DEFAULT '0',
  `reg_date` datetime NOT NULL,
  `invite_num` int(8) NOT NULL,
  `money` decimal(12,2) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `user_name`, `email`, `pass`, `passwd`, `t`, `u`, `d`, `plan`, `transfer_enable`, `port`, `switch`, `enable`, `type`, `last_get_gift_time`, `last_check_in_time`, `last_rest_pass_time`, `reg_date`, `invite_num`, `money`) VALUES
(12, 'xing8567476', 'xing8567476@163.com', 'f3fcddb9686ec89fd82c57a32cf4e9a3', '82184', 1429710707, 1211699051, 2178960502, 'A', 108194168832, 50004, 1, 1, 7, 0, 1429620914, 0, '2015-04-05 20:00:32', 0, '0.00'),
(13, 'lxfy1995', '1125432569@qq.com', '4c7e67ac4df6de21f34e2654c00d7b07', '35418', 1429666946, 7904375, 1999424804, 'A', 11468275712, 50009, 1, 1, 7, 0, 1429524838, 0, '2015-04-05 20:21:15', 0, '0.00'),
(14, 'blackberry', '904591828@qq.com', '952681977218989289da69f5b4c186cf', '59033', 1429350068, 39690, 337136, 'A', 11290017792, 50012, 1, 1, 7, 0, 1429349703, 0, '2015-04-05 20:26:08', 0, '0.00'),
(15, 'juebanpig', 'juebanpig@126.com', 'e4900e15018b28275b87cb68158629bb', '66098', 1428485246, 796290, 3146362, 'A', 14193524736, 50019, 1, 1, 7, 0, 1429490245, 0, '2015-04-05 20:27:32', 0, '0.00'),
(16, 'montana', '17706912@qq.com', '2c908504409260b5572337622d130190', '58448', 1429444413, 13569276, 441224852, 'A', 15986589696, 50023, 1, 1, 7, 0, 1429682597, 0, '2015-04-05 20:31:28', 0, '0.00'),
(17, 'isser123', 'e7qq123@gmail.com', '00936b9285d6b8665ae9122993fb8e91', '39292', 1429437764, 38133991, 2206875613, 'A', 11681136640, 50026, 1, 1, 7, 0, 1429344182, 0, '2015-04-05 20:31:39', 0, '0.00'),
(18, 'westbank', 'haizhizi@gmail.com', '2c908504409260b5572337622d130190', '64756', 1429440280, 3646680, 496132740, 'A', 15321792512, 50029, 1, 1, 7, 0, 1429682618, 0, '2015-04-05 20:31:59', 0, '0.00'),
(19, 'bygreencn', 'bygreen@163.com', '5e90db17dcf7f7ab78002ba470886017', '87176', 1429711563, 10115316, 142332473, 'A', 15006171136, 50036, 1, 1, 7, 0, 1429708342, 0, '2015-04-05 20:52:12', 0, '0.00'),
(20, 'vampirels1314', 'vampirels1314@outlook.com', '23cea0fcf307fd0687f3639fd448fccc', '14527', 1429595165, 22361831, 1210329694, 'A', 12157190144, 50040, 1, 1, 7, 0, 1429454431, 0, '2015-04-05 23:16:54', 0, '0.00'),
(21, 'gmail384340', '384340@gmail.com', '86bfb270615a2cf932168b82f36c5e6c', '94934', 1429752115, 13370088, 176711149, 'A', 15976103936, 50044, 1, 1, 7, 0, 1429748715, 0, '2015-04-06 08:55:01', 0, '0.00'),
(22, 'qhkj999', 'gg1997@gmail.com', '26d4f6149281e89ecdf4ed4d1888ccc2', '28377', 0, 0, 0, 'A', 14211350528, 50046, 1, 1, 7, 0, 1429697910, 0, '2015-04-06 23:15:25', 0, '0.00'),
(23, 'abc123nba', '839623781@qq.com', '0659c7992e268962384eb17fafe88364', '87711', 1429195892, 657865, 48017947, 'A', 11933843456, 50050, 1, 1, 7, 0, 1429268048, 0, '2015-04-15 21:54:51', 0, '0.00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
