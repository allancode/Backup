-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2015 at 07:46 PM
-- Server version: 5.5.41-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shadowsocks`
--

-- --------------------------------------------------------

--
-- Table structure for table `invite_code`
--

CREATE TABLE IF NOT EXISTS `invite_code` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) NOT NULL,
  `user` int(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3678 ;

--
-- Dumping data for table `invite_code`
--

INSERT INTO `invite_code` (`id`, `code`, `user`) VALUES
(3670, 'jpshadU5Yzk0ZDhkMGNiZWRjOTczND', 1),
(3671, 'newusYjljNmNhMmFlZTJkZjA4Y2Yw', 1),
(3674, 'fresaE2NGJlNjYzNjgyZThjYjAzN2', 0),
(3676, 'fresaE1ZGExZjJiNWU1ZWQ2ZTY4Mz', 0),
(3677, 'fresaTYxZWVkNGJjZWVjNTY0YTAwM', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ss_admin`
--

CREATE TABLE IF NOT EXISTS `ss_admin` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(128) CHARACTER SET utf8mb4 NOT NULL,
  `email` varchar(32) NOT NULL,
  `pass` varchar(32) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ss_admin`
--

INSERT INTO `ss_admin` (`uid`, `admin_name`, `email`, `pass`) VALUES
(1, 'admin', 'admin@gmail.com', 'b4328659d8289e07cca449f61b7155ec');

-- --------------------------------------------------------

--
-- Table structure for table `ss_node`
--

CREATE TABLE IF NOT EXISTS `ss_node` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `node_name` varchar(128) NOT NULL,
  `node_type` int(3) NOT NULL,
  `node_server` varchar(128) NOT NULL,
  `node_method` varchar(64) NOT NULL,
  `node_info` varchar(128) NOT NULL,
  `node_status` varchar(128) NOT NULL,
  `node_order` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ss_node`
--

INSERT INTO `ss_node` (`id`, `node_name`, `node_type`, `node_server`, `node_method`, `node_info`, `node_status`, `node_order`) VALUES
(1, '日本节点', 0, '157.7.115.198', 'aes-256-cfb', '日本节点，可翻墙。', '可用', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ss_reset_pwd`
--

CREATE TABLE IF NOT EXISTS `ss_reset_pwd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `init_time` int(11) NOT NULL,
  `expire_time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `uni_char` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `ss_reset_pwd`
--

INSERT INTO `ss_reset_pwd` (`id`, `init_time`, `expire_time`, `user_id`, `uni_char`) VALUES
(0, 1424448190, 1424534590, 1, '2MzU5ODFkYzM4MmVkZTM2ZTdjNGNhNDI'),
(1, 1425140415, 1425226815, 33, 'wN2Q4NjZkMGY0MjNmY2ZlNDI0Yzc2OTI'),
(2, 1425140427, 1425226827, 33, 'Y1ZDFiN2Y0ZTRlN2M0NjIxODJiZTBjNW'),
(3, 1425140681, 1425227081, 33, 'Yzk3M2IyOTdlNmU2YzYwYmI4YTlhNDBl'),
(4, 1425140851, 1425227251, 33, 'zA1ZTMwZjU0ZWQyNzI0ZGNkZWM2MTEwN'),
(5, 1425169306, 1425255706, 33, 'jVkZDliZDRkM2ExODJiZTBjNWNkY2Q1M'),
(6, 1425308658, 1425395058, 35, 'IzOTY5NjA0MTg0MGUwNTg2NDUxYzM4M2'),
(7, 1425308685, 1425395085, 35, 'zViYzJlMWE3NzkyYWUzODYxYzM4M2NkM'),
(8, 1425309083, 1425395483, 35, 'YxMTIxYTRkZDg1YjI5MDJjMDVkZDQxYz'),
(9, 1425309092, 1425395492, 35, 'zNWVmMjZlZjVjMTY5NDQwMjkxYzM4M2N'),
(10, 1425309286, 1425395686, 35, 'EwZjA0YTcyNjExNjRiNDE2NjJkNDgxYz');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(128) CHARACTER SET utf8mb4 NOT NULL,
  `email` varchar(32) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `passwd` varchar(16) NOT NULL,
  `t` int(11) NOT NULL DEFAULT '0',
  `u` bigint(20) NOT NULL,
  `d` bigint(20) NOT NULL,
  `plan` varchar(2) CHARACTER SET utf8mb4 NOT NULL,
  `transfer_enable` bigint(20) NOT NULL,
  `port` int(11) NOT NULL,
  `switch` tinyint(4) NOT NULL DEFAULT '1',
  `enable` tinyint(4) NOT NULL DEFAULT '1',
  `type` tinyint(4) NOT NULL DEFAULT '1',
  `last_get_gift_time` int(11) NOT NULL DEFAULT '0',
  `last_check_in_time` int(11) NOT NULL DEFAULT '0',
  `last_rest_pass_time` int(11) NOT NULL DEFAULT '0',
  `reg_date` datetime NOT NULL,
  `invite_num` int(8) NOT NULL,
  `money` decimal(12,2) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `user_name`, `email`, `pass`, `passwd`, `t`, `u`, `d`, `plan`, `transfer_enable`, `port`, `switch`, `enable`, `type`, `last_get_gift_time`, `last_check_in_time`, `last_rest_pass_time`, `reg_date`, `invite_num`, `money`) VALUES
(12, 'xing8567476', 'xing8567476@163.com', 'f3fcddb9686ec89fd82c57a32cf4e9a3', '53487', 1427028621, 4685604594, 17548092353, 'A', 53687091200, 50007, 1, 1, 7, 0, 1425116746, 0, '2015-02-28 17:45:21', 1, 0.00),
(15, 'hzth008', 'hzth008@gmail.com', '25f9e794323b453885f5181f1b624d0b', '14556', 1426416731, 6786908, 257717699, 'A', 15029239808, 50011, 1, 1, 7, 0, 1425830684, 0, '2015-02-28 23:21:54', 0, 0.00),
(16, 'isser123', 'e7qq123@gmail.com', '8ad5d940cb9004a9eb39d05aa9fd7468', '47399', 1427003197, 20572254, 169146092, 'A', 16008609792, 50013, 1, 1, 7, 0, 1426928387, 0, '2015-02-28 23:23:02', 0, 0.00),
(17, 'parking', 'asenuq@gmail.com', '701334cdbf5a1f166fef2d54027d228c', '57499', 1426947460, 8541052, 1366347336, 'A', 19702743040, 50017, 1, 1, 7, 0, 1426947019, 0, '2015-02-28 23:24:17', 0, 0.00),
(18, 'qhkj999', 'gg1997@gmail.com', '26d4f6149281e89ecdf4ed4d1888ccc2', '87639', 1425903087, 108523, 507719, 'A', 25311576064, 50024, 1, 1, 7, 0, 1427023658, 0, '2015-02-28 23:25:24', 0, 0.00),
(19, 'yuhoo2008', 'yuhoo_online@163.com', 'd635e5c231fad65d25c79cc8f624c177', '34546', 1426055877, 119380253, 249094117, 'A', 15265169408, 50029, 1, 1, 7, 0, 1426087132, 0, '2015-02-28 23:29:11', 0, 0.00),
(20, 'njcxy001', 'njcxy001@sina.com', 'cb52ea16da68396d716c4cafd08a46b7', '32974', 0, 0, 0, 'A', 13191086080, 50032, 1, 1, 7, 0, 1425137504, 0, '2015-02-28 23:31:30', 0, 0.00),
(21, 'SigmaAlgebra', 'qsj19921123@gmail.com', 'e8cf6437bd5edf5482d74115e1bf450b', '26244', 0, 0, 0, 'A', 13468958720, 50039, 1, 1, 7, 0, 1425137556, 0, '2015-02-28 23:32:11', 0, 0.00),
(22, 'twtpyud', 'twtpyud@gmail.com', 'd0c88150ac8b08f01e8396c1a65c6459', '14811', 1425313477, 464, 3801, 'A', 18559795200, 50045, 1, 1, 7, 0, 1425393802, 0, '2015-02-28 23:33:18', 0, 0.00),
(23, 'jien007', 'taoliwuyan008@163.com', '2a712039654f886106afdcdcddc266ef', '81628', 1427002206, 48631788, 1095002913, 'A', 19915603968, 50048, 1, 1, 7, 0, 1426574504, 0, '2015-02-28 23:34:34', 0, 0.00),
(24, 'sw20031128', 'sw20031128@gmail.com', '6475b685ec72021ad0ac6f334deffe8e', '55623', 1425622308, 13476740, 277472995, 'A', 14920187904, 50055, 1, 1, 7, 0, 1426676944, 0, '2015-02-28 23:34:47', 0, 0.00),
(25, 'yyj88900', 'yyj88900@163.com', '09b2f2977eed9ce430cf24651639a73f', '67198', 1426575038, 653395, 33933760, 'A', 28972154880, 50060, 1, 1, 7, 0, 1427000835, 0, '2015-03-01 00:04:30', 0, 0.00),
(26, 'wcyntrg', 'wangchyrg@gmail.com', 'a96b9835320c3f14da4d9dd4ced0fe85', '95248', 0, 0, 0, 'A', 15638462464, 50064, 1, 1, 7, 0, 1425139590, 0, '2015-03-01 00:05:50', 0, 0.00),
(27, 'eminemtb', 'lor3@live.cn', '8176c16a97d315fcf40bb28165950693', '29075', 0, 0, 0, 'A', 14058258432, 50067, 1, 1, 7, 0, 1425139944, 0, '2015-03-01 00:07:17', 0, 0.00),
(28, 'ChengTongXue', 'chengtongxue@outlook.com', '0ff886e6b44fc0c21fc141ab1dd077f6', '70897', 1426206976, 7908044, 184303152, 'A', 19490930688, 50071, 1, 1, 7, 0, 1426206891, 0, '2015-03-01 00:07:48', 0, 0.00),
(29, 'seramat', 'seramat@qq.com', '25d55ad283aa400af464c76d713c07ad', '29619', 1426432697, 335771, 9532576, 'A', 16433283072, 50078, 1, 1, 7, 0, 1426420453, 0, '2015-03-01 00:07:50', 0, 0.00),
(30, 'florescence', 'mshoen23@gmail.com', 'b37178ebd3e8dffbd9291659fc1b8149', '36056', 1426343402, 5830327, 76915397, 'A', 22663921664, 50085, 1, 1, 7, 0, 1426827177, 0, '2015-03-01 00:09:02', 0, 0.00),
(31, 'jiangjikai', 'jjk19961@outlook.com', '6906784f4de5511e3b2d5340183c6768', '66598', 1427074849, 42828610, 1515080845, 'A', 23006806016, 50090, 1, 1, 7, 0, 1426861356, 0, '2015-03-01 00:09:43', 0, 0.00),
(32, 'andrewblake', 'plm63091126@gmail.com', 'f97b6ec32544b5e6dfbd459cca60edef', '77597', 1426952597, 4171245, 310931260, 'A', 23328718848, 50096, 1, 1, 7, 0, 1427032636, 0, '2015-03-01 00:09:53', 0, 0.00),
(33, 'oldbeauty', 'oldbeautyx@gmail.com', '25d55ad283aa400af464c76d713c07ad', '11236', 1427035573, 82451672, 3127268370, 'A', 30193745920, 50103, 1, 1, 7, 0, 1427034407, 0, '2015-03-01 00:11:41', 0, 0.00),
(34, 'somebodyj', 'sj@sharklasers.com', '65748c17b5bb305fca67c40b2f936d1f', '56877', 1426258471, 1734863, 777445385, 'A', 15839789056, 50108, 1, 1, 7, 0, 1426688682, 0, '2015-03-01 00:14:04', 0, 0.00),
(35, 'allanxing', 'xingpeng2010@126.com', 'f3fcddb9686ec89fd82c57a32cf4e9a3', '94628', 1426911851, 251377770, 18331970798, 'A', 107374182400, 50111, 1, 1, 7, 0, 1426295527, 0, '2015-03-01 10:29:10', 0, 0.00),
(36, 'asdwang', '497356877@qq.com', '859be0cd5ba024e47773bae2d22850ed', '90121', 1426044885, 1122108, 4172610, 'A', 11168382976, 50115, 1, 1, 7, 0, 1425990667, 0, '2015-03-10 20:30:44', 0, 0.00),
(37, 'abc123nba', '839623781@qq.com', '0659c7992e268962384eb17fafe88364', '60872', 1426998646, 2156012, 343942229, 'A', 11667505152, 50120, 1, 1, 7, 0, 1425990735, 0, '2015-03-10 20:31:55', 0, 0.00),
(38, 'pzlionhkzhang', 'pzlionhkzhang@hotmail.com', 'ea84636f589be77bc2ea77021bb2332c', '89014', 0, 0, 0, 'A', 11654922240, 50125, 1, 1, 7, 0, 1426859232, 0, '2015-03-14 22:36:09', 0, 0.00),
(39, 'sircheng', 'mr.chenghaihui@gmail.com', '0362cb95167c311db57a8baf9e262836', '61540', 1427006095, 9294325, 690539238, 'A', 11766071296, 50131, 1, 1, 7, 0, 1426690591, 0, '2015-03-15 10:09:11', 0, 0.00),
(40, 'asd234ddd', '237833542@qq.com', '1e55dbf412cb74d5e2c21fb6452408c7', '15268', 0, 0, 0, 'A', 10931404800, 50137, 1, 1, 7, 0, 1426947809, 0, '2015-03-21 22:22:34', 0, 0.00),
(41, 'sdkjdxcxs', 'sdkjdxcxs@gmail.com', '1f3750e6ad6fb57ddfc95af92eb1474b', '79694', 1427023440, 1721885, 12898474, 'A', 11270094848, 50140, 1, 1, 7, 0, 1426949798, 0, '2015-03-21 22:55:43', 0, 0.00),
(42, 'keyer123', 'keyer@163.com', '4c58f892780c646fa5e08c004aa9fed7', '44808', 0, 0, 0, 'A', 11100225536, 50146, 1, 1, 7, 0, 1426982567, 0, '2015-03-22 08:02:18', 0, 0.00);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
