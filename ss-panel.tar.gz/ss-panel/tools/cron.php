<?php
require_once '../lib/config.php';
//流量清空
require_once 'reset_transfer.php';