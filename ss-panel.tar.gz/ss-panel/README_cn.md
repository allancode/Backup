ss-panel
========

A simple front end of Shadowsocks  https://github.com/mengskysama/shadowsocks/tree/manyuser

[演示](https://cattt.com) [安装&更新教程](https://bbs.yekuba.com/forum-38-1.html)


### 安装
* 导入sql目录下的所有sql文件到数据库
* 重命名文件 lib/config-sample.php 为 config.php，并修改数据库连接信息，并根据提示修改初始流量等。
* 访问index.php试试看

 

### 管理
* 建议修改admin文件夹名字
* 访问 /admin
* 默认管理员: admin 密码: 12345678
