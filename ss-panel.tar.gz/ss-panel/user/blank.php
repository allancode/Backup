<!DOCTYPE html>
<html>
<head>
    <title>管理后台</title>
    <?php include_once 'lib/header.inc.php'; ?>
</head>
<body class="skin-blue">
<?php include_once 'lib/nav.inc.php';
include_once 'lib/slidebar_left.inc.php';  ?>
<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            用户中心
            <small>User Panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i>FreeShadowSocks</a></li>
            <li class="active">UserCenter</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    </section><!-- /.content -->
</aside><!-- /.right-side --> 
<?php include_once 'lib/footer.inc.php'; ?>
</body>
</html>
