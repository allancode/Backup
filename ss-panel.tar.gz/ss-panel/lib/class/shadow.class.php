<?php
/**
 * Shadow
 */

class shadow {


    private $dbc;
    public  $uid;

    function  __construct(){
        global $dbc;
        $this->dbc = $dbc;
    }

    //添加一个Shadow
    function add_shadow(){

    }

    //del
    function del_shadow(){

    }
} 