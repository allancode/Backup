<div class="header">
    <ul class="nav nav-pills pull-right" role="tablist">
        <li role="presentation"><a href="index.php">主页</a></li>
        <li role="presentation"><a href="user/login.php">登录</a></li>
        <li role="presentation"><a href="user/reg.php">注册</a></li>
        <li role="presentation"><a href="invite_code.php">邀请码</a></li>
        <li role="presentation"><a href="user">用户中心</a></li>
    </ul>
    <h3 class="text-muted"><?php echo $site_name; ?></h3>
</div>
