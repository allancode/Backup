<div class="footer">
    <p>&copy; <?php echo $site_name."  ".date('Y'); ?>  Power by <a href="http://freess.fkgfw.tk">FreeShadowSocks</a> <?php echo "v1.0"; ?></p>
</div>
